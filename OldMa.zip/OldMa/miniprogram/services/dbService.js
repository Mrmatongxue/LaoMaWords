wx.cloud.init();

//数据库服务

module.exports = { db: wx.cloud.database() };